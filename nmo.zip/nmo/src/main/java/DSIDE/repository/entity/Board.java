package DSIDE.repository.entity;

import org.hibernate.annotations.Entity;

@Entity
public class Board {
    private Long id;
    private String title;
    private String contentd;

}
