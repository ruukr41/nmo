package DSIDE.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import static java.lang.System.out;


@org.springframework.stereotype.Controller
public class BoardController {

@GetMapping("/bo")//localhost:8080/bo/write
public String boardWriteForm() {
return "bo";
}

@PostMapping("/bo/read")
public String boardReadForm(String title, String content) {


return "";

}
}
